package com.ianhearne.tvdbexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TvdbexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(TvdbexamApplication.class, args);
	}

}
